<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_helloworld
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * HelloWorld Controller
 *
 * @package     Joomla.Administrator
 * @subpackage  com_helloworld
 * @since       0.0.9
 */
class HelloWorldControllerHelloWorld extends JControllerForm
{


    function updateuser(){
        $this->postData		=	(array)JFactory::getApplication()->input->getArray();
        $app			=   &JFactory::getApplication();

        JModelLegacy::addIncludePath(JPATH_SITE.'/components/com_helloworld/models');
        $umbrellaModel 	= JModelLegacy::getInstance('HelloWorlds', 'HelloWorldModel');
        $umbrellaModel->updateUserData($this->postData);
        $app->redirect('http://localhost/beunique/index.php?option=com_helloworld&view=helloworlds&layout=editlist&id='.$this->postData['id'],'Successfully updated');
    }
    
    function deleteuser(){
        $this->postData		=	(array)JFactory::getApplication()->input->getArray();
        $app			=   &JFactory::getApplication();

        JModelLegacy::addIncludePath(JPATH_SITE.'/components/com_helloworld/models');
        $umbrellaModel 	= JModelLegacy::getInstance('HelloWorlds', 'HelloWorldModel');
        $umbrellaModel->deleteuserData($this->postData);
        $app->redirect('http://localhost/beunique/index.php/team','Successfully deleted');
    }
    
    function insertuserData(){
        $this->postData		=	(array)JFactory::getApplication()->input->getArray();
        $app			=   &JFactory::getApplication();
        

        JModelLegacy::addIncludePath(JPATH_SITE.'/components/com_helloworld/models');
        $umbrellaModel 	= JModelLegacy::getInstance('HelloWorlds', 'HelloWorldModel');
        $umbrellaModel->insertuserData($this->postData);
        $app->redirect('http://localhost/beunique/index.php/team','Successfully Added');
	}
}
