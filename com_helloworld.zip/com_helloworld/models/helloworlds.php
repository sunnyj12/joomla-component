<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_helloworld
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * HelloWorldList Model
 *
 * @since  0.0.1
 */
class HelloWorldModelHelloWorlds extends JModelList
{

	/**
	 * Method to build an SQL query to load the list data.
	 *
	 * @return      string  An SQL query
	 */
	public function updateUserData($requestData=null){

		
		
			$db = JFactory::getDbo();
			$query = $db->getQuery(true);
					// Fields to update.
			$fields = array(
			$db->quoteName('greeting') . ' = ' . $db->quote($requestData['name']),
			$db->quoteName('Designation') . ' = ' . $db->quote($requestData['Designation']),
			$db->quoteName('Dept') . ' = ' . $db->quote($requestData['project']),
			$db->quoteName('project') . ' = ' . $db->quote($requestData['project']),
			$db->quoteName('shift') . ' = ' . $db->quote($requestData['shift'])

			);

			

			// Conditions for which records should be updated.
			$conditions = array(
			
			$db->quoteName('id') . ' = ' . $db->quote($requestData['id'])
			);

			
			$query->update($db->quoteName('#__helloworld'))->set($fields)->where($conditions);
			//$query->update($db->quoteName('#__test2'))->set($fields2)->where($conditions);

			$db->setQuery($query);

			$result = $db->execute();
	}
	public function getOptions($itemId=0)
	{
		$db    = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select('*');
		$query->from('#__helloworld');
		if($itemId>0){
			$query->where('id='.$itemId);
		}
		$db->setQuery($query);
		$messages = $db->loadObjectList();
		return $messages;

		}

		public function deleteuserData($requestData=null){
	    
			$db = JFactory::getDbo();

			$query = $db->getQuery(true);

			// delete all custom keys for user 1001.
			$conditions = array(			
				$db->quoteName('id') . ' = ' . $db->quote($requestData['id'])
			);

			$query->delete($db->quoteName('#__helloworld'));
			$query->where($conditions);

			$db->setQuery($query);

			$result = $db->execute();

			
		

		}

		public function insertuserData($requestData=null){

	

							// Get a db connection.
				$db = JFactory::getDbo();

				// Create a new query object.
				$query = $db->getQuery(true);

				// Insert columns.
				$columns = array('greeting', 'Designation', 'Dept', 'project' ,'shift');

				// Insert values.
				$values = array(
					$db->quote($requestData['name']),
					$db->quote($requestData['Designation']),
					$db->quote($requestData['Dept']),
					$db->quote($requestData['project']),
					$db->quote($requestData['shift'])
		
					);
				

				// Prepare the insert query.
				$query
					->insert($db->quoteName('#__helloworld'))
					->columns($db->quoteName($columns))
					->values(implode(',', $values));

					

				// Set the query using our newly populated query object and execute it.
				$db->setQuery($query);
				$db->execute();
	}
	// protected function insertData()
	// {
	// 	// Check the session for previously entered form data.
	// 	$data = JFactory::getApplication()->getUserState(
	// 		'com_helloworld.edit.helloworld.data',
	// 		array()
	// 	);

	// 	if (empty($data))
	// 	{
	// 		$data = $this->getItem();
	// 	}

	// 	return $data;
	// }
}
