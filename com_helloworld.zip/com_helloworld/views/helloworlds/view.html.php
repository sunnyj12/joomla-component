<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_helloworld
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * HelloWorlds View
 *
 * @since  0.0.1
 */

class HelloWorldViewHelloWorlds extends JViewLegacy
{
	/**
	 * Display the Hello World view
	 *
	 * @param   string  $tpl  The name of the template file to parse; automatically searches through the template paths.
	 *
	 * @return  void
	 */
	function display($tpl = null)
	{

		JModelLegacy::addIncludePath (JPATH_ROOT .'/components/com_helloworld/models');
		$JModel =JModelLegacy::getInstance('HelloWorlds', 'HelloWorldModel');
		$this->postData		=	(array)JFactory::getApplication()->input->getArray();
		$this->itemID	=	$this->postData[id];
		
        
		

		$this->items=$JModel->getOptions($this->itemID);
		//echo "<pre>";print_r($this->items);

				// Display the template
		parent::display($tpl);
	}

	/**
	 * Add the page title and toolbar.
	 *
	 * @return  void
	 *
	 * @since   1.6
	 */
	
}