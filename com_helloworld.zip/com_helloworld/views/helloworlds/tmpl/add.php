<form id="intelselForm"  enctype="multipart/form-data" method="post" name="intelselForm" autocomplete="off">

<table class="table">
              <tr>
            <td>Name</td>
            <td><input type="text" class="form-control " name="name" id="name" value="<?php echo (isset($this->postData['name']))? $this->postData['name']: '';?>" title="Please enter Name."></td> 
            </tr>
            <tr>
            <td>Designation</td>
            <td><input type="text" class="form-control " name="Designation" id="Designation" value="<?php echo (isset($this->postData['Designation']))? $this->postData['Designation']: '';?>" title="Please enter Designation."></td> 
            </tr>
            <tr>
            <td>Dept</td>
            <td><input type="text" class="form-control " name="Dept" id="Dept" value="<?php echo (isset($this->postData['Dept']))? $this->postData['Dept']:'';?>" title="Please enter Dept."></td>
            </tr>
            <tr>
            <td>Project</td>
            <td><input type="text" class="form-control " name="project" id="project" value="<?php echo (isset($this->postData['project']))? $this->postData['project']:'';?>" title="Please enter project."></td>
            <td>Shift</td>
            <td><input type="text" class="form-control " name="shift" id="shift" value="<?php echo (isset($this->postData['shift']))? $this->postData['shift']:'';?>" title="Please enter shift."></td>
            <td>Company Mail ID</td>
            <td><input type="text" class="form-control " name="companymailid" id="companymailid" value="<?php echo (isset($this->postData['companymailid']))? $this->postData['companymailid']:'';?>" title="Please enter companymailid."></td>
             </tr>
            

            

            
            </tr>
            <tr >
            <td style="text-algin:center">
            <input type="hidden" name="option" value="com_helloworld" />
            <input type="hidden" name="task" value="helloworld.insertuserData" />
			<input type="submit" name="insertData" value="ADD" title="Add" id="insertData" class="btn-intel btn">
			<?php echo JHtml::_('form.token'); ?>
            </td>
            </tr>
       
    </table>
</form>