

<?php 

    defined('_JEXEC') or die;

    

    $user = JFactory::getUser();
    $userid =$user->get('id');
      ?>
    

    <table class="table">
        <thead>
            <tr>
                <th># </th>
                <th>Name </th>
                <th>Designation </th>
                <th>Dept</th>
                <th>Project</th>
                <th>Shift</th>
                <th>Company Mail ID</th>
                <th>Personal Mail ID</th>
                <th>Contact No</th>
                <th>Delete </th>
            </tr>
        </thead>
        <tbody>
        <?php 
       // echo "<pre>";print_r($this->items);die;
        foreach($this->items as $i => $item) : ?>
            <tr>
                <td scope="row"><?php echo $i+1; ?></td>
                <td><a href="http://localhost/beunique/index.php?option=com_helloworld&view=helloworlds&layout=editlist&id=<?php echo $item->id?>"><?php  echo $item->greeting;  ?></td>
                <td><?php  echo $item->Designation;  ?></td>
                <td><?php  echo $item->Dept;  ?></td>
                <td><?php  echo $item->project;  ?></td>
                <td><?php  echo $item->shift;  ?></td>
                <td><?php  echo $item->companymailid;  ?></td>
                <td><?php  echo $item->personalmailid;  ?></td>
                <td><?php  echo $item->contactno;  ?></td>
                <td><a href="http://localhost/beunique/index.php?option=com_helloworld&task=helloworld.deleteuser&id=<?php echo $item->id?>">Delete</td>
            </tr>
            
            <?php endforeach; ?>
            <tr>
            <td><a href="http://localhost/beunique/index.php?option=com_helloworld&view=helloworlds&layout=add">ADD</td>
</tr>
            
        </tbody>
    </table>

